package com.delzai.app
import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.*
import androidx.webkit.WebViewAssetLoader
import com.google.mediapipe.tasks.genai.llminference.*
import java.io.File
import java.util.concurrent.Executors

class MainActivity : Activity() {
  lateinit var wv: WebView
  var fcb: ValueCallback<Array<Uri>>? = null
  val ex = Executors.newSingleThreadExecutor()
  var engine: LlmInference? = null
  var session: LlmInferenceSession? = null

  // Модель из assets копируется один раз в память приложения
  fun modelPath(): String {
    val f = File(filesDir, "qwen.task")
    if (!f.exists() || f.length() == 0L) {
      val t = File(filesDir, "qwen.tmp")
      assets.open("qwen.task").use { i -> t.outputStream().use { i.copyTo(it, 1 shl 20) } }
      t.renameTo(f)
    }
    return f.absolutePath
  }
  fun js(t: String, done: Boolean, err: String? = null) {
    val a = org.json.JSONObject.quote(t); val e = if (err == null) "null" else org.json.JSONObject.quote(err)
    runOnUiThread { wv.evaluateJavascript("window.__llm&&window.__llm($a,$done,$e)", null) }
  }

  inner class Bridge {
    @JavascriptInterface fun generate(prompt: String) {
      ex.execute {
        try {
          if (engine == null) engine = LlmInference.createFromOptions(this@MainActivity,
            LlmInference.LlmInferenceOptions.builder().setModelPath(modelPath()).setMaxTokens(1280).build())
          session?.close()
          session = LlmInferenceSession.createFromOptions(engine!!,
            LlmInferenceSession.LlmInferenceSessionOptions.builder().setTopK(40).setTemperature(0.7f).build())
          session!!.addQueryChunk(prompt)
          session!!.generateResponseAsync { part, done -> js(part ?: "", done) }
        } catch (e: Throwable) { js("", true, e.message ?: "ошибка модели") }
      }
    }
    @JavascriptInterface fun stop() { try { session?.cancelGenerateResponseAsync() } catch (_: Throwable) {} }
  }

  @SuppressLint("SetJavaScriptEnabled")
  override fun onCreate(b: Bundle?) {
    super.onCreate(b)
    requestPermissions(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO), 1)
    val loader = WebViewAssetLoader.Builder().addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
    wv = WebView(this); setContentView(wv)
    wv.settings.apply { javaScriptEnabled = true; domStorageEnabled = true; mediaPlaybackRequiresUserGesture = false; allowFileAccess = false }
    wv.addJavascriptInterface(Bridge(), "AndroidLLM")
    wv.webViewClient = object : WebViewClient() {
      override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest) = loader.shouldInterceptRequest(r.url)
    }
    wv.webChromeClient = object : WebChromeClient() {
      override fun onPermissionRequest(r: PermissionRequest) { runOnUiThread { r.grant(r.resources) } }
      override fun onShowFileChooser(v: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
        fcb?.onReceiveValue(null); fcb = cb
        startActivityForResult(p.createIntent(), 7); return true
      }
    }
    wv.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
    ex.execute { try { modelPath() } catch (_: Throwable) {} }
  }
  override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
    if (rq == 7) { fcb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs, d)); fcb = null }
  }
  override fun onBackPressed() { if (wv.canGoBack()) wv.goBack() else super.onBackPressed() }
}
